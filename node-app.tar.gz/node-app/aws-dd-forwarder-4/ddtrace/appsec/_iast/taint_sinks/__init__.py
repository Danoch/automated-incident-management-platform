from .ast_taint import ast_function


__all__ = [
    "ast_function",
]
