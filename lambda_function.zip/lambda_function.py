import json
import boto3
import os
import logging

# Inicializar clientes AWS
ec2_client = boto3.client('ec2')
sns_client = boto3.client('sns')

# Obtener el ARN del SNS desde variables de entorno
SNS_TOPIC_ARN = os.environ.get("SNS_TOPIC_ARN")

# Configurar logger
logger = logging.getLogger()
logger.setLevel(logging.INFO)

def lambda_handler(event, context):
    logger.info(f"🚀 Lambda triggered with event: {json.dumps(event)}")
    
    detail = event.get('detail', {})
    instance_id = detail.get('instanceId', "UNKNOWN")

    if instance_id != "UNKNOWN":
        try:
            ec2_client.reboot_instances(InstanceIds=[instance_id])
            message = f"🔴 High CPU usage detected! Restarting EC2 instance: {instance_id}"
        except Exception as e:
            message = f"❌ Failed to restart EC2 instance {instance_id}: {str(e)}"
            logger.error(message)
    else:
        message = "⚠ Incident detected, but no instance information found."
        logger.warning(message)

    try:
        sns_client.publish(
            TopicArn=SNS_TOPIC_ARN,
            Message=message,
            Subject="🚨 Incident Response Triggered"
        )
    except Exception as e:
        logger.error(f"❌ Failed to send SNS notification: {str(e)}")

    return {
        'statusCode': 200,
        'body': json.dumps({'message': message})
    }
