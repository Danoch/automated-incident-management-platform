from enum import IntEnum


class ITR_SKIPPING_LEVEL(IntEnum):
    TEST = 0
    SUITE = 1
