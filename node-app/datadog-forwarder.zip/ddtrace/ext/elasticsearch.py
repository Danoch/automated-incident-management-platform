SERVICE = "elasticsearch"
APP = "elasticsearch"

# standard tags
URL = "elasticsearch.url"
METHOD = "elasticsearch.method"
TOOK = "elasticsearch.took"
PARAMS = "elasticsearch.params"
BODY = "elasticsearch.body"
