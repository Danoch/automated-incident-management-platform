# tags
ID = "usr.id"
NAME = "usr.name"
EMAIL = "usr.email"
ROLE = "usr.role"
SCOPE = "usr.scope"
SESSION_ID = "usr.session_id"
EXISTS = "usr.exists"
