from typing import Union


StringType = Union[None, str, bytes]
