"""
Limits for trace data.
"""

MAX_SPAN_META_KEY_LEN = 200
MAX_SPAN_META_VALUE_LEN = 25000
